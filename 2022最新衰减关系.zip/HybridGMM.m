 
%  2022 Hybrid ground motion prediciton model. Citation for
%
% Provides ground-mtion prediction equations for computing medians 
% of average horizontal components of PGA, PGV and 5%
% damped linear pseudo-absolute aceeleration response spectra
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input Variables
% M             = Magnitude
% T             = Period (sec);
%                 Use 1000 for output the array of Sa with period
% Rrup          = Closest distance coseismic rupture (km)
% Rjb           = Joyner-Boore distance (km)
% Rx            = Closest distance to the surface projection of the
%                   coseismic fault rupture plane
% W             = down-dip width of the fault rupture plane
%                   if unknown, input: 999
% Ztor          = Depth to the top of coseismic rupture (km)
%                   if unknown, input: 999
% Zbot          = Depth to the bottom of the seismogenic crust
%               needed only when W is unknow;
% delta         = average dip of the rupture place (degree)
% lambda        = rake angle (degree) - average angle of slip measured in
%                   the plance of rupture
% Fhw           = hanging wall effect
%               = 1 for including
%               = 0 for excluding
% Vs30          = shear wave velocity averaged over top 30 m (m/s)
% Z25           = Depth to the 2.5 km/s shear-wave velocity horizon (km)
%                   if in California or Japan and Z2.5 is unknow, then
%                   input: 999
% Zhyp          = Hypocentral depth of the earthquake measured from sea level
%                   if unknown, input: 999
% region        = 0 for global (incl. Taiwan)
%               = 1 for California
%               = 2 for Japan
%               = 3 for China or Turkey
%               = 4 for Italy
% Output Variables
% Sa            = Median spectral acceleration prediction
% sigma         = logarithmic standard deviation of spectral acceleration
%                 prediction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Sa, sigma, period1] = HybridGMM(M, T, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, lambda, Fhw, Vs30, Z25, Zhyp, region)

% Period
period = [0 -1 0.010 0.020 0.030 0.050 0.075 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.75 1 1.5 2 3 4 5 7.5 10];

% Set initial A1100 value to 999. A1100: median estimated value of PGA on rock with Vs30 = 1100m/s
A1100 = 999;

% Style of faulting
Frv = (lambda > 30 & lambda < 150);
Fnm = (lambda > -150 & lambda < -30);

% if Ztor is unknown..
if Ztor == 999
    if Frv == 1
        Ztor = max(2.704 - 1.226*max(M-5.849,0),0)^2;
    else
        Ztor = max(2.673 - 1.136*max(M-4.970,0),0)^2;
    end
end

% if W is unknown...
if W == 999
    if Frv == 1
        Ztori = max(2.704 - 1.226*max(M-5.849,0),0)^2;
    else
        Ztori = max(2.673 - 1.136*max(M-4.970,0),0)^2;
    end
        W = min(sqrt(10^((M-4.07)/0.98)),(Zbot - Ztori)/sin(pi/180*delta));    

        Zhyp = 9;         
end

% if Zhyp is unknown...
if Zhyp == 999 && W ~= 999
    if M < 6.75
        fdZM = -4.317 + 0.984*M;
    else
        fdZM = 2.325;
    end
    
    if delta <= 40
        fdZD = 0.0445*(delta-40);
    else
        fdZD = 0;
    end

    if Frv == 1
        Ztori = max(2.704 - 1.226*max(M-5.849,0),0)^2;
    else
        Ztori = max(2.673 - 1.136*max(M-4.970,0),0)^2;
    end
    
    Zbor = Ztori + W*sin(pi/180*delta); % The depth to the bottom of the rupture plane
    d_Z = exp(min(fdZM+fdZD,log(0.9*(Zbor-Ztori))));
    Zhyp = d_Z + Ztori;
       
end

%%
% Compute Sa and sigma with pre-defined period
if length (T) == 1 && T == 1000
    Sa=zeros(1,length(period)-2);
    sigma=zeros(1,length(period)-2);
    period1=period(1:end-2);
   
    for ipT=1:length(period1)
        [Sa(ipT),sigma(ipT)]=HybridGMM_sub (M, ipT, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, Fhw, Vs30, Z25, Zhyp,lambda, Frv, Fnm, region, A1100);
        [PGA,~]=HybridGMM_sub (M, 1, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, Fhw, Vs30, Z25, Zhyp,lambda, Frv, Fnm, region, A1100);
        if Sa(ipT)<PGA && period1(ipT)<0.25
            Sa(ipT)= PGA;
        end
    end
% Compute Sa and sigma with user-defined period    
else                            
    Sa=zeros(1, length(T));
    sigma=zeros(1, length(T));
    period1=T;
    for i=1:length(T)
        Ti = T(i);
        if ( isempty(find(abs(period-Ti) < 0.0001, 1))) % The user defined period requires interpolation
            T_low = max(period(period < Ti));
            T_high = min(period(period > Ti));
            ip_low  = find(period==T_low);
            ip_high = find(period==T_high);
            
            [Sa_low, sigma_low] = HybridGMM_sub (M, ip_low, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, Fhw, Vs30, Z25, Zhyp,lambda, Frv, Fnm, region, A1100);
            [Sa_high, sigma_high] = HybridGMM_sub (M, ip_high, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, Fhw, Vs30, Z25, Zhyp,lambda, Frv, Fnm, region, A1100);
            [PGA,~]=HybridGMM_sub (M, 1, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, Fhw, Vs30, Z25, Zhyp,lambda, Frv, Fnm, region, A1100);
       
            x = [log(T_low) log(T_high)];
            Y_sa = [log(Sa_low) log(Sa_high)];
            Y_sigma = [sigma_low sigma_high];
            Sa(i) = exp(interp1(x, Y_sa, log(Ti)));
            sigma(i) = interp1(x, Y_sigma, log(Ti));
            
            if Sa(i)<PGA && period1(i)<0.25
                Sa(i)= PGA;
            end
        else
            ip_T = find(abs((period- Ti)) < 0.0001);
            [Sa(i), sigma(i)] = HybridGMM_sub (M, ip_T, Rrup, Rjb, Rx, W, Ztor,Zbot,delta, Fhw, Vs30, Z25, Zhyp,lambda, Frv, Fnm, region,A1100);
            [PGA,~]=HybridGMM_sub (M, 1, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, Fhw, Vs30, Z25, Zhyp,lambda, Frv, Fnm, region, A1100);
            
            if Sa(i)<PGA && period1(i)<0.25
                Sa(i)= PGA;
            end
        end
    end
end
 
function [Sa, sigma] = HybridGMM_sub (M, ip, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, Fhw, Vs30, Z25in, Zhyp, lambda,Frv, Fnm, region, A1100)
c	= [1.7525	1.0918	1.1534	1.3279	1.7168	1.6817	1.5079	1.4177	1.1867	1.2779	1.3403	1.5860	1.2878	1.4074	1.6845	1.7174	0.7213	0.7441	0.0220	0.1899	0.6202	0.3454	0.0061];
c0	= [-4.4488	-2.9577	-4.3765	-4.4206	-4.0215	-3.4867	-3.3211	-3.6841	-4.8858	-5.4402	-5.9923	-6.5011	-7.7884	-8.4862	-9.8804	-11.0669	-12.5314	-12.9876	-13.3249	-14.0283	-14.5617	-15.5068	-15.9624];
c1	= [0.9307	1.4558	0.9507	0.9150	0.8664	0.8541	0.8036	0.9585	1.2208	1.3071	1.4054	1.4561	1.6808	1.8163	1.9868	2.1395	2.2270	2.2449	2.1394	2.1321	2.1172	2.2384	2.1648];
c2 = [0.5055	0.2570	0.4934	0.5195	0.5748	0.5655	0.7492	0.6978	0.5004	0.4070	0.1704	0.1376	-0.1016	-0.1979	-0.1790	-0.2198	-0.0405	0.0588	0.3445	0.7313	1.0270	0.2072	0.4262];
c3 = [-1.3690	-1.1970	-1.4379	-1.4877	-1.4548	-1.5461	-1.3726	-1.4688	-1.5245	-1.5815	-1.5210	-1.6919	-1.4330	-1.5062	-1.7228	-1.7040	-1.6005	-1.5261	-1.3171	-1.4673	-1.6552	-0.6897	-0.6980];
c4 = [-0.5519	-0.2850	-0.5098	-0.2856	-0.4842	-0.1210	-0.6542	-0.6390	-0.4863	-0.3991	-0.2607	0.0535	-0.1659	-0.1494	-0.0454	-0.1137	-0.3045	-0.5366	-0.8095	-0.8110	-0.7142	-0.9738	-1.0515];
c5	= [-2.7175	-2.4333	-2.7485	-2.6689	-2.7585	-2.7658	-2.7035	-2.6187	-2.4262	-2.3623	-2.3234	-2.2307	-2.0941	-2.1455	-2.1613	-2.0919	-1.9200	-2.0491	-2.0238	-1.9757	-2.0056	-2.1646	-2.2285];
c6	= [0.2441	0.2206	0.2460	0.2388	0.2491	0.2355	0.2255	0.2059	0.1810	0.1827	0.1888	0.1857	0.1692	0.1778	0.1895	0.1781	0.1553	0.1679	0.1557	0.1426	0.1473	0.1835	0.1990]; 
c7	= [6.8209	5.9224	7.1041	6.0232	6.2792	6.4871	6.4493	7.3923	8.0569	8.2994	7.5800	6.6321	5.9114	7.0384	6.3759	6.5669	5.9042	7.8058	7.9600	8.6597	9.4789	9.3197	7.4049];
c8	= [-0.2094	-0.3980	-0.2080	-0.1944	-0.2159	-0.2043	-0.2169	-0.1848	-0.1827	-0.1809	-0.1701	-0.1241	-0.1378	-0.1318	-0.1638	-0.1163	-0.1725	-0.2467	-0.3256	-0.3970	-0.4816	-0.5586	-0.8339];
c9	= [-0.3687	-0.3429	-0.3837	-0.3138	-0.3502	-0.3104	-0.3527	-0.4183	-0.4803	-0.4100	-0.4335	-0.3801	-0.3709	-0.4576	-0.2293	0.0093	0.1026	0.0820	-0.0442	-0.2229	-0.4559	-0.6836	-0.7721];
c10	= [0.9627	0.7779	1.1698	1.2113	1.2117	1.2942	1.3729	1.0409	1.3083	1.2573	1.2565	1.2763	1.2839	1.2191	1.3220	1.1352	1.0803	0.9669	0.6323	-0.4075	-0.7571	-0.4906	-1.0831];
c11	= [1.0030	1.6832	1.0100	1.1156	1.1838	1.3374	1.4367	1.5545	1.8253	2.0365	2.1945	2.3735	2.4592	2.4198	2.0200	1.4775	0.4097	-0.4300	-0.7354	-0.6991	-0.6512	-0.5261	-0.3921];
c12	= [1.0447	2.6412	1.1537	1.0660	1.1127	0.9446	1.6067	1.7699	2.2216	2.6634	2.8006	3.0130	3.2088	2.9803	2.2311	2.0027	1.6290	0.8880	0.6498	0.5956	0.4451	0.1991	-0.2868];
c13= [1.3206	2.4181	1.3046	1.3860	1.4267	1.4896	1.7078	1.7615	2.0679	2.3237	2.5294	2.7270	2.9524	2.9765	2.6929	2.2251	1.2549	0.4193	0.1329	0.1764	0.1170	0.0899	-0.1137];
c14	= [-0.2665	0.2205	-0.2244	-0.2987	-0.3054	-0.4392	-0.5252	-0.3826	-0.2884	-0.1299	0.0236	0.1366	0.3133	0.4075	0.5856	0.7028	0.8660	0.8810	0.8146	0.6675	0.6225	0.5402	0.5209];
c15= [0.0413	0.2072	-0.0418	0.0518	0.0114	-0.0912	-0.0954	-0.2029	-0.1137	-0.0741	-0.1193	-0.1750	-0.1410	-0.0551	0.0062	0.0026	0.0331	0.0706	0.1023	0.1987	0.1302	0.1125	0.0653];
c16	= [0.3358	0.5122	0.2142	0.3440	0.2245	0.1730	0.2146	0.0761	0.1316	0.1943	0.2701	0.3873	0.4186	0.4216	0.4768	0.4516	0.3447	0.4583	0.4786	0.5950	0.6033	0.7797	0.7677];
c17	= [0.0793	0.0497	0.0785	0.0777	0.0836	0.0860	0.0920	0.0869	0.0743	0.0640	0.0555	0.0482	0.0386	0.0266	0.0147	0.0069	0.0037	0.0032	0.0073	0.0098	0.0067	0.0035	0.0203];
c18	= [0.0434	0.0290	0.0446	0.0505	0.0437	0.0465	0.0355	0.0372	0.0468	0.0531	0.0571	0.0652	0.0641	0.0636	0.0629	0.0652	0.0510	0.0374	0.0285	0.0217	0.0082	-0.0005	-0.0299];
c19	= [0.0064	0.0053	0.0063	0.0054	0.0062	0.0046	0.0064	0.0065	0.0067	0.0068	0.0053	0.0040	0.0033	0.0029	0.0035	0.0031	0.0030	0.0040	0.0042	0.0066	0.0093	0.0034	0.0035];
c20	= [-0.0062	-0.0031	-0.0061	-0.0064	-0.0063	-0.0066	-0.0077	-0.0078	-0.0077	-0.0071	-0.0066	-0.0062	-0.0050	-0.0041	-0.0027	-0.0019	-0.0012	-0.0002	0.0004	0.0002	0.0002	0.0006	0.0008];
k1 = [863.7718	399.7892	864.5297	862.6096	907.3416	1052.4684	1082.8694	1031.3590	877.5684	747.5972	653.6687	586.0662	501.9521	456.5398	409.9512	399.9315	399.6751	399.9228	399.9141	399.9387	399.9234	399.8921	399.7247];
k2= [-1.2807	-1.9792	-1.2745	-1.3365	-1.3728	-1.4540	-1.5702	-1.6920	-1.9873	-2.2298	-2.4109	-2.5564	-2.6739	-2.6807	-2.3925	-1.9431	-1.0110	-0.2528	0.0759	0.0719	0.0696	0.0750	0.1288];
k3	= [1.6722	1.8409	1.6509	1.7768	1.6704	1.7096	1.5757	1.5796	1.5851	1.6361	1.6556	1.7134	1.7179	1.6656	1.6346	1.6430	1.6382	1.7513	1.9190	2.1038	2.2215	2.5370	2.8860];
h1	= [0.4478	0.8228	0.2525	0.2431	0.2257	0.2348	0.1049	-0.0744	0.1295	0.1165	0.2056	0.1758	-0.0246	0.1941	0.4143	0.5522	0.7032	1.0021	1.1199	-0.2503	-0.1736	-0.3625	-0.4401];
h2	= [1.1442	1.4300	1.6237	1.7523	1.6253	1.6800	1.5695	1.4141	1.6449	1.7592	1.8420	1.7995	1.7471	1.8240	1.5589	1.4580	1.1176	1.0080	1.1966	1.2449	1.1748	1.4750	1.1462];
h3	= [-0.0762	-0.1637	-0.5838	-0.6073	-0.6341	-0.4793	-0.4844	-0.5710	-0.5457	-0.4996	-0.7827	-0.6316	-0.2685	-0.6295	-0.7190	-0.6705	-0.5527	-0.6045	-0.8466	-1.9228	-1.4268	-1.0346	-0.4517];
h4	= [1.7754	1.7701	1.5857	1.6196	1.6183	1.6461	1.5833	1.1768	1.5363	1.6141	1.5852	1.6355	1.4745	1.5005	1.4983	1.3298	1.3538	1.4040	1.5118	0.1529	0.0687	0.7511	0.4013];
h5	= [-0.5944	0.8225	-0.2578	0.2572	-0.2538	-0.3252	-1.0527	-1.1423	-1.1330	-0.4743	0.4260	0.7863	1.5026	1.1194	1.3849	2.1223	2.5787	2.1071	1.5551	2.1156	2.4978	1.5841	2.1536];
h6	= [0.0572	-1.3471	-0.5690	-0.8589	-0.5962	-0.4734	-1.3153	-1.3047	-1.2539	-0.8893	-1.0504	-0.9581	-1.2903	-0.8764	-1.1542	-1.4957	-1.5295	-1.8569	-1.5531	2.0926	2.1499	0.9377	2.5207];
n	= [1.2782	1.2073	1.2720	1.3102	1.2816	1.2889	1.2870	1.2526	1.2429	1.2301	1.2184	1.2299	1.2154	1.2021	1.1732	1.1688	1.1622	1.1238	1.0379	1.0152	1.0180	1.1810	1.2396];
a2 = [-0.3549	-0.8250	-0.4160	-0.5006	-0.3756	-0.5872	-0.4208	0.2908	-0.5334	-0.5374	-0.5716	-0.6096	-0.5063	-0.4671	-0.5059	-0.4841	-0.6393	-0.6498	-0.7355	1.3221	1.2859	1.7896	0.5599];
Dc20_JI = [-0.0025	0.0007	-0.0027	-0.0023	-0.0027	-0.0029	-0.0027	-0.0026	-0.0022	-0.0023	-0.0023	-0.0021	-0.0020	-0.0020	-0.0021	-0.0020	-0.0007	-0.0002	0.0003	0.0004	0.0009	0.0012	0.0010];
Dc20_CH = [0.0055	0.0024	0.0055	0.0054	0.0057	0.0058	0.0073	0.0077	0.0072	0.0062	0.0052	0.0043	0.0036	0.0025	0.0009	0.0004	0.0110	0.0123	0.0140	0.0097	0.0049	-0.0003	0.0040];
Dc20 =  [	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0];
f1	= [0.737	0.639	0.739	0.740	0.752	0.790	0.800	0.787	0.791	0.786	0.761	0.737	0.701	0.681	0.638	0.620	0.595	0.581	0.588	0.587	0.591	0.587	0.577];
f2	= [0.571	0.524	0.571	0.572	0.579	0.617	0.626	0.639	0.638	0.635	0.631	0.633	0.633	0.635	0.650	0.659	0.643	0.639	0.646	0.651	0.681	0.706	0.691];
t1	= [0.452	0.383	0.454	0.453	0.469	0.549	0.568	0.521	0.478	0.442	0.421	0.406	0.387	0.394	0.414	0.430	0.448	0.456	0.472	0.477	0.488	0.477	0.475];
t2	= [0.277	0.355	0.277	0.278	0.279	0.319	0.376	0.314	0.340	0.340	0.338	0.344	0.379	0.318	0.387	0.405	0.464	0.455	0.446	0.442	0.465	0.552	0.641];
flnAF	= [0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300	0.300];
rlnPGA_lnY =[1.0000	0.6858	0.9996	0.9987	0.9945	0.8643	0.8287	0.9034	0.8978	0.8906	0.8759	0.8514	0.7458	0.7434	0.6286	0.5393	0.4414	0.3789	0.3417	0.3230	0.3002	0.2479	0.2418];


% Adjustment factor based on region
if region == 2
    Dc20 = Dc20_JI;
elseif region ==4
    Dc20 = Dc20_JI;
elseif region == 3
    Dc20 = Dc20_CH;
end
% if region is in Japan...
Sj = region==2;

% if Z2.5 is unknown...
if Z25in == 999
    if region ~= 2  % if in California or other locations
        Z25 = exp(7.089 - 1.144 * log(Vs30));
        Z25A = exp(7.089 - 1.144 * log(1100));
    elseif region == 2  % if in Japan
        Z25 = exp(5.359 - 1.102 * log(Vs30));
        Z25A = exp(5.359 - 1.102 * log(1100));
    end
else
% Assign Z2.5 from user input into Z25 and calc Z25A for Vs30=1100m/s
    if region ~= 2  % if in California or other locations
        Z25 = Z25in;
        Z25A = exp(7.089 - 1.144 * log(1100));
    elseif region == 2  % if in Japan
        Z25 = Z25in;
        Z25A = exp(5.359 - 1.102 * log(1100));
    end
end

%%
% Magnitude dependence
if M <= 4.5
    fmag = c0(ip) + c1(ip) * M;
elseif M <= 5.5
    fmag = c0(ip) + c1(ip) * M + c2(ip) * (M - 4.5);
elseif M <= 6.5
    fmag = c0(ip) + c1(ip) * M + c2(ip) * (M - 4.5) + c3(ip) * (M - 5.5);
else
    fmag = c0(ip) + c1(ip) * M + c2(ip) * (M - 4.5) + c3(ip) * (M - 5.5) + c4(ip) * (M-6.5);
end

%% Geometric attenuation term
fdis = (c5(ip) + c6(ip) * M) * log(sqrt(Rrup^2 + c7(ip)^2));

%% Style of faulting
if M <=4.5
    F_fltm = 0;
elseif M<= 5.5
    F_fltm = M-4.5;
else
    F_fltm = 1;
end

fflt = ((c8(ip) * Frv) + (c9(ip) * Fnm))*F_fltm;

%% Hanging-wall effects
  
    R1 = W * cos(pi/180*delta); % W - downdip width
    R2 = 62* M - 350;
    
    f1_Rx = h1(ip)+h2(ip)*(Rx/R1)+h3(ip)*(Rx/R1)^2;
    f2_Rx = h4(ip)+h5(ip)*((Rx-R1)/(R2-R1))+h6(ip)*((Rx-R1)/(R2-R1))^2;
    
    if Fhw == 0 || Rx<0
        f_hngRx = 0;
    elseif Rx < R1 && Fhw == 1
        f_hngRx = f1_Rx;
    elseif Rx >= R1 && Fhw == 1
        f_hngRx = max(f2_Rx,0);
    end
    
    if Rrup ==0
        f_hngRup = 1;
    else
        f_hngRup = (Rrup-Rjb)/Rrup;
    end
    
    if M <= 5.5
        f_hngM = 0;
    elseif M <= 6.5
        f_hngM = (M-5.5)*(1+a2(ip)*(M-6.5));
    else
        f_hngM = 1+a2(ip)*(M-6.5);
    end
    
    if Ztor <= 16.66
        f_hngZ = 1-0.06*Ztor;
    else
        f_hngZ = 0;
    end
    
    f_hngdelta = (90-delta)/45;
    
    fhng = c10(ip) * f_hngRx * f_hngRup * f_hngM * f_hngZ * f_hngdelta;



%% Site conditions

if Vs30 <= k1(ip)
    if A1100 == 999
       A1100 = HybridGMM (M, 0, Rrup, Rjb, Rx, W, Ztor, Zbot, delta, lambda, Fhw, 1100, Z25A, Zhyp, region);
    end
    
    f_siteG = c11(ip) * log(Vs30/k1(ip)) + k2(ip) * (log(A1100 + c(ip) * (Vs30/k1(ip))^n(ip)) - log(A1100 + c(ip)));
    
elseif Vs30 > k1(ip)
    f_siteG = (c11(ip) + k2(ip) * n(ip)) * log(Vs30/k1(ip));
end

if Vs30 <= 200
    f_siteJ = (c12(ip)+k2(ip)*n(ip))*(log(Vs30/k1(ip))-log(200/k1(ip)))*Sj;
else
    f_siteJ = (c13(ip)+k2(ip)*n(ip))*log(Vs30/k1(ip))*Sj;
end

fsite = f_siteG + f_siteJ;
%% Basin Response Term - Sediment effects

if Z25 <= 1
    fsed = (c14(ip)+c15(ip)*Sj) * (Z25 - 1);
elseif Z25 <= 3
    fsed = 0;
elseif Z25 > 3
    fsed = c16(ip) * k3(ip) * exp(-0.75) * (1 - exp(-0.25 * (Z25 - 3)));
end

%% Hypocenteral Depth term
if Zhyp <= 7
    f_hypH = 0;
elseif Zhyp <= 20
    f_hypH = Zhyp - 7;
else
    f_hypH = 13;
end

if M <= 5.5
    f_hypM = c17(ip);
elseif M <= 6.5
    f_hypM = c17(ip)+ (c18(ip)-c17(ip))*(M-5.5);
else
    f_hypM = c18(ip);
end

fhyp = f_hypH * f_hypM;

%% Fault Dip term
if M <= 4.5
    f_dip = c19(ip)* delta;
elseif M <= 5.5
    f_dip = c19(ip)*(5.5-M)* delta;
else
    f_dip = 0;
end

%% Anelastic Attenuation Term

if Rrup >80
    f_atn = (c20(ip) + Dc20(ip))*(Rrup-80);
else
    f_atn = 0;
end

%% Median value
Sa = exp(fmag + fdis + fflt + fhng + fsite + fsed + fhyp + f_dip + f_atn);

%% Standard deviation computations

if M <= 4.5
    tau_lny = t1(ip);
    tau_lnPGA = t1(22);   % ip = PGA
    phi_lny = f1(ip);
    phi_lnPGA = f1(22);
elseif M < 5.5
    tau_lny = t2(ip)+(t1(ip)-t2(ip))*(5.5-M);
    tau_lnPGA = t2(22)+(t1(22)-t2(22))*(5.5-M);    %ip = PGA
    phi_lny = f2(ip)+(f1(ip)-f2(ip))*(5.5-M);
    phi_lnPGA = f2(22)+(f1(22)-f2(22))*(5.5-M);
else
    tau_lny = t2(ip);
    tau_lnPGA = t2(22);
    phi_lny = f2(ip);
    phi_lnPGA = f2(22);
end

tau_lnyB = tau_lny;
tau_lnPGAB = tau_lnPGA;
phi_lnyB = sqrt(phi_lny^2-flnAF(ip)^2);
phi_lnPGAB = sqrt(phi_lnPGA^2-flnAF(ip)^2);

if (Vs30 < k1(ip))
    alpha = k2(ip) * A1100 * ((A1100 + c(ip)*(Vs30/k1(ip))^n(ip))^(-1) - (A1100+c(ip))^(-1));
else
    alpha = 0;
end

tau = sqrt(tau_lnyB^2 + alpha^2*tau_lnPGAB^2 + 2*alpha*rlnPGA_lnY(ip)*tau_lnyB*tau_lnPGAB);
phi = sqrt(phi_lnyB^2 + flnAF(ip)^2 + alpha^2*phi_lnPGAB^2 + 2*alpha*rlnPGA_lnY(ip)*phi_lnyB*phi_lnPGAB);

sigma=sqrt(tau^2+phi^2);




